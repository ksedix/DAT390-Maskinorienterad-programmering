#include <stdio.h>
#include <stdlib.h>
#define MAX_POINTS 30
#define SIMULATOR    



 
 
__attribute__((naked)) __attribute__((section (".start_section")) )
void startup ( void )
{
__asm__ volatile(" LDR R0,=0x2001C000\n");		/* set stack */
__asm__ volatile(" MOV SP,R0\n");
__asm__ volatile(" BL main\n");					/* call main */
__asm__ volatile(".L1: B .L1\n");				/* never return */
}


//port D används av keypad.

#define GPIOD	0x40020C00
#define GPIOD_MODER ((unsigned int*) GPIOD)
#define GPIOD_IDR	((unsigned short*)	(GPIOD+0x10))
#define GPIOD_IDR_HIGH	((unsigned char*) (GPIOD+0x11))
#define GPIOD_ODR	((unsigned short*) (GPIOD+0x14))
#define GPIOD_ODR_HIGH	((unsigned char*) (GPIOD+0x15))
#define GPIOD_OTYPER	((unsigned short*) (GPIOD+4))
#define GPIOD_PUPDR		((unsigned int*) (GPIOD+0xC))
#define GPIOD_PUPDR_HIGH	((unsigned short*) (GPIOD+0xE))

#define	SysTick	0xE000E010
#define STK_CTRL	((unsigned int*) SysTick)
#define STK_LOAD	((unsigned int*) SysTick+4)
#define STK_VAL	((unsigned int*) SysTick+8)



//port E används av den grafiska displayen

#define PORT_E	0x40021000
#define GPIOE_MODER	((unsigned int*) PORT_E)
#define GPIOE_OTYPER	((unsigned short*)(PORT_E+4))
#define GPIOE_OSPEEDR	((unsigned int*)PORT_E+8)
#define GPIOE_PUPDR	((unsigned int*)PORT_E+0xC)
#define SIMULATOR

//byte-adresser för data och styrregister som LCD-display ska anslutas till.
#define GPIOE_IDRLOW	((unsigned char*)(PORT_E + 0x10))
#define GPIOE_IDRHIGH	((unsigned char*)(PORT_E + 0x11))
#define GPIOE_ODRLOW	((unsigned char*)(PORT_E + 0x14))
#define GPIOE_ODRHIGH	((unsigned char*)(PORT_E + 0x15))


//SysTick
#define	SysTick	0xE000E010
#define STK_CTRL	((unsigned int*) SysTick)
#define STK_LOAD	((unsigned int*) SysTick+4)
#define STK_VAL	((unsigned int*) SysTick+8)


//bitar i styrregistret hos display-modul.
#define B_E	0x40
#define B_SELECT	4
#define B_RW	2
#define B_RS	1










__attribute__((naked))
void graphic_initialize(void)
{
	__asm volatile (".HWORD	0xDFF0\n");
	__asm volatile (" BX LR\n");
}


__attribute__((naked))
void graphic_pixel_set(int x, int y)
{
	__asm volatile (".HWORD	0xDFF2\n");
	__asm volatile (" BX LR\n");
}

__attribute__((naked))
void graphic_clear_screen(void)
{
	__asm volatile (".HWORD	0xDFF1\n");
	__asm volatile (" BX LR\n");
}

__attribute__((naked))
void graphic_pixel_clear(int x, int y)
{
	__asm volatile (".HWORD	0xDFF3\n");
	__asm volatile (" BX LR\n");
}




void app_init(void){
	
	//Konfigurering av GPIO D-portens register med en keypad ansluten till pinnar D8-15 och 7segmentsdisplay ansluten till pinnar D0-7.
	
	//GPIO_MODER konfig
	// bit 31-16 konfigurerar keypad. bit 15-0 används för konfigurera output till 7segmentsdisplay.
	*GPIOD_MODER=0x55005555;
	
	//konfigurera push-pull på utpinnarna till keypad och på utpinnarna till 7segdisplay
	*GPIOD_OTYPER=0x0000; 
	
	//konfigurera pull-down på inpinnarna till keypad.
	*GPIOD_PUPDR_HIGH=0b10101010;
	
	//konfigurering av PORT E
	*GPIOE_MODER=0x55555555;
	
}


//ASCII DISPLAY FUNKTIONER..


//korrekt ✅


//ettställ bitar i styrregistret
void ascii_ctrl_bit_set(unsigned char x){
	
	
	*GPIOE_ODRLOW= *GPIOE_ODRLOW | x | B_SELECT ;
	
	
}



//korrekt ✅



//nollställ bitar i styrregistret
void ascii_ctrl_bit_clear(unsigned char x){
	
	unsigned char c= *GPIOE_ODRLOW & ~x;
	*GPIOE_ODRLOW= c | B_SELECT;
	
	
}



//korrekt ✅
//funktion för att skriva till ascii-displayen.
void ascii_write_controller(unsigned char command){
	
	delay_250ns();
	ascii_ctrl_bit_set(B_E);             //sätt E till 1(positiv flank) för att starta skrivcykeln.
	*GPIOE_ODRHIGH=command;
	delay_250ns();
	ascii_ctrl_bit_clear(B_E);          //sätt E till 0(negativ flank) för att avsluta skrivcykeln.
	
}



//korrekt ✅
//funktion för att skriva kommando till ascii-displayen.
void ascii_write_cmd(unsigned char command){
	
	//sätt RW till 0 och RS till 0 för att skriva kommando.
	ascii_ctrl_bit_clear(B_RS);
	ascii_ctrl_bit_clear(B_RW);               
	ascii_write_controller(command);
	
}



//korrekt ✅
//funktion för att skriva data till ascii-displayen
void ascii_write_data(unsigned char data){
	
	
	//sätt RW till 0 och RS till 1 för att skriva data.
	ascii_ctrl_bit_clear(B_RW);
	ascii_ctrl_bit_set(B_RS);               
	ascii_write_controller(data);
	
}




//läser från ascii-displayen

//korrekt ✅
unsigned char ascii_read_controller(void){
	
	ascii_ctrl_bit_set(B_E);
	
	//jag kan inte få den till 360ns, eftersom min funktion delay_250ns är för stor. Är detta lösningen?
	delay_250ns();
	delay_250ns();
	
	//läs från dataregistret
	unsigned char rv= *GPIOE_IDRHIGH;
	
	
	//sätt bit E till 0.
	ascii_ctrl_bit_clear(B_E);
	
	return rv;
	
	
	
}


//läs data från ascii-displayen
//korrekt ✅
unsigned char ascii_read_data(){
	
	//sätt port E15-8 till ingång och E7-0 till utgång.
	*GPIOE_MODER=0x00005555;
	
	
	//sätt bit RW till 1 och bit RS till 1 för att läsa data
	ascii_ctrl_bit_set(B_RW);
	ascii_ctrl_bit_set(B_RS);
	
	unsigned char rv= ascii_read_controller();
	
	*GPIOE_MODER=0x55555555;
	
	return rv;
	
}


//korrekt ✅
unsigned char ascii_read_status(){
	
	//sätt port E15-8 (dataregistret) till ingång
	*GPIOE_MODER=0x00005555;
	
	
	//sätt bit RW till 1 och bit RS till 0 för att läsa status.
	ascii_ctrl_bit_clear(B_RS);
	ascii_ctrl_bit_set(B_RW);
	
	unsigned char rv= ascii_read_controller();
	
	//sätt dataregistret som utgång
	*GPIOE_MODER=0x55555555;
	
	return rv;
	
	
	
}




//funktion för att skriva kommando


//korrekt✅
void ascii_command(command){
	
	while((ascii_read_status() & 0x80)==0x80);
	delay_mikro(8);
	ascii_write_cmd(command);
	delay_milli(2);
	
	//fördröj specifik fördröjning? vad menas?
	
}



//korrekt✅
void ascii_init(void){
	
	//Function Set
	ascii_command(00111000);
	
	//Display control, display på, markör på, konstant visning
	ascii_command(00001110);
	
	//Clear display
	ascii_command(1);
	
	//Entry Mode Set. adressering med increment. inget skift av adressbufferten.
	ascii_command(000000110);
	
	
}


//korrekt✅
void ascii_gotoxy(char x,char y){
	
	char adress=x-1;
	if (y==2){
		adress=adress+0x40;
	}
	ascii_write_cmd(0x80|adress);
	
}


//korrekt✅
void ascii_write_char(unsigned char c){
	
	while(ascii_read_status() & 0x80==0x80);
	
	delay_mikro(8);
	
	ascii_write_data(c);
	
	delay_mikro(50);
	

}
















void ActivateRow(unsigned int row){
	
	
//sätter output pin(4 output pins) till 1 för den raden som ska aktiveras.
	
	switch(row){
		case 1: *GPIOD_ODR_HIGH=0x10;
		break;
		case 2: *GPIOD_ODR_HIGH=0x20;
		break;
		case 3: *GPIOD_ODR_HIGH=0x40;
		break;
		case 4: *GPIOD_ODR_HIGH=0x80;
		break;
		default:
		*GPIOD_ODR_HIGH=0;
		break;
	}
}



//läser av vilken kolumn som är tryckt. kommer endast funka om raden också är aktiv.
int ReadColumn(){
	
	//check if the row is active by reading the Input data register of port D. 
	
	if (*GPIOD_IDR_HIGH & 8){
		return 4;
	} 
	if (*GPIOD_IDR_HIGH & 4){
		return 3;
	}
	if (*GPIOD_IDR_HIGH & 2){
		return 2;
	}
	if (*GPIOD_IDR_HIGH & 1){
		return 1;
	}
	return 0;
	
}


unsigned char keyb(void){
		
		int row,col;
		unsigned char keycode;
		unsigned char keycodes[4][4]={{1,2,3,0xA},{4,5,6,0xB},{7,8,9,0xC},{0xE,0,0xF,0xD}};
		
		for (row=1;row<=4;row++){
			ActivateRow(row);
			col=ReadColumn();
			if (col!=0) {
				keycode= keycodes[row-1][col-1];
				ActivateRow(0);
				return keycode;
			}
			
			}
			keycode=0xFF;
			ActivateRow(0);
			return keycode;
		
	}








//creates a delay of 250ns using systick
void delay_250ns(){
	
	*STK_CTRL=0;  //återställ systick
	*STK_LOAD=42;  //ladda räknaren med värdet 42;
	*STK_VAL=0;		//nollställ systick val.
	
	
	//varför ska man sätta bit 2 till 1? det gör ingen skillnad.
	*STK_CTRL=5;   //starta räknaren
	if (0x10000 & *STK_CTRL){
		return;
	}
	
	
	
	
	
}

void delay_mikro(unsigned int us){
	
	#ifdef SIMULATOR
	us/=250;
	us++;
	#endif
	
	int repeat=4*us;
	
	for (int i=0;i<repeat;i++){
		delay_250ns();
	}
	
}


void delay_milli(unsigned int ms){
	
	#ifdef SIMULATOR
	ms/=250;
	#endif
	
	//1 millisekund är 1000 mikrosekunder
	int repeat=1000*ms;
	
	for (int i=0;i<repeat;i++){
		delay_mikro(1);
	}

	
}





//strukturer vi använder//

typedef struct
{
	char x,y;
} POINT,*PPOINT;


typedef struct{
	
	int numpoints;
	int sizex;
	int sizey;
	
	//a list of points;
	POINT px[MAX_POINTS];
	
}	GEOMETRY, *PGEOMETRY;



typedef struct tObj{
	
	PGEOMETRY geo;
	int dirx,diry;
	int posx,posy;
	
	
	void (*draw) (struct tObj*);
	void (*clear) (struct tObj*);
	void (*move) (struct tObj*);
	void (*set_speed) (struct tObj*, int , int );
	
}	OBJECT, *POBJECT;


//objekt vi använder//


GEOMETRY ball_geometry=
{
	
	12,
	4,4,
	{
		{0,1},{0,2},{1,0},{1,1},{1,2},{1,3},{2,0},{2,1},{2,2},{2,3},{3,1},{3,2}
	}
	
	
	
};





//nånting fel med dessa funktioner?

//draw a pixel where each point of the ballobject is located at
void draw_ballobject(POBJECT o){
	//iterate through each point in the array.
	for (int i=0;i<o->geo->numpoints;i++){
	POINT p=o->geo->px[i];
	graphic_pixel_set(p.x+o->posx,p.y+o->posy);
	}
	
}

void clear_ballobject(POBJECT o){
	
	//iterate through each point in the array.
	for (int i=0;i<o->geo->numpoints;i++){
	POINT p=o->geo->px[i];
	graphic_pixel_clear(p.x+o->posx,p.y+o->posy);
	
	
}
	
}


//rör bollen i objektets riktning.
void move_ballobject(POBJECT o){
	
	
	o->clear(o);
	
	
		//om någon av bollens pixlar är mindre än 1.
	//den kommer studsa fram och tillbak utanför skärmen om du inte gör detta.
	
	if (o->posx<1){
		
		o->dirx*=-1;
		
	}
	if (o->posx+4>128){
		
		o->dirx*=-1;
		//GAME OVER if the ball gets outside of the right wall
		
		
	}
	
	if (o->posy<1){
		
		o->diry*=-1;
		
	}
	if (o->posy+4>64){
		
		o->diry*=-1;
		
	}

	//addera riktningskoordinaterna
	o->posx+=o->dirx;
	o->posy+=o->diry;

	
	
	o->draw(o);

	
}
	
	
	
	//it will not be able to change properties of the object if you dont give it a pointer
void move_spider_object(POBJECT o){
	
	
	o->clear(o);
		
	//addera riktningskoordinaterna
	o->posx+=o->dirx;
	o->posy+=o->diry;



	o->draw(o);
	
	
	
}
	

	




void set_ballobject_speed(POBJECT o, int xspeed, int yspeed){
	
	o->dirx=xspeed;
	o->diry=yspeed;
	
}




//vi skapar våran boll som vi kommer använda

static OBJECT ballobject=
{
	
	&ball_geometry,
	0,0,   //dirx, diry
	2,2, 	//posx,posy
	draw_ballobject,
	clear_ballobject,
	move_ballobject,
	set_ballobject_speed
	
};


//use the class geomtry to create the object.


GEOMETRY spider_geometry={
	
	22,
	6,8,
	
	{
	{0,2},{0,3},{0,7},{1,1},{1,2},{1,4},{1,6},{2,0},{2,2},{2,3},{2,5},{3,0},{3,2},{3,3},{3,5},{4,1},{4,2},{4,4},{4,6},{5,2},{5,3},{5,7}
	}
	
	
};

static OBJECT spiderobject= 
{
	&spider_geometry,
	0,0,
	50,56,                       //bottom middle
	draw_ballobject,
	clear_ballobject,
	move_spider_object,
	set_ballobject_speed
};


//checks if 2 objects overlap, have a point on the same (x,y)
int objects_overlap(OBJECT one, OBJECT two){
	
	for (int i=0;i<one.geo->numpoints;i++){
		for (int j=0;j<two.geo->numpoints;j++){
			POINT	o1=	one.geo->px[i];
			POINT	o2= two.geo->px[j];
			if (o1.x+one.posx==o2.x+two.posx && o1.y+one.posy==o2.y+two.posy){
				return 1;
			}
			
	}
	}
	
	return 0;
	
	
	
}



int spider_outside_area(OBJECT spider){
	
	if (spider.posx<1 || spider.posx+6>124 || spider.posy<1 || spider.posy+8>64){
		return 1;
	}
	return 0;
	
	
}


//parametrar blir kopior.


//Q: if we want to change an object inside a function, we have to use a pointer to the object. but why?

//projektet fungerar men bollen uppdateras inte så ofta. kolla hur det set ut för roger.

void main(void)
{
	
	char c;
	OBJECT ballcopy=ballobject;
	POBJECT victim=&ballcopy;
	OBJECT creature=spiderobject;
	POBJECT spider=	&creature ;
	int win=0;
	
	
	app_init();
	graphic_initialize();
	graphic_clear_screen();
	victim->set_speed(victim,2,1);
	
	
	while(1){
		
		victim->move(victim);
		spider->move(spider);
		
		c=keyb();
		switch(c){
			
			//set_speed är inte en funktion...
			
			//case 6:	p->set_speed(p,1,0);	break;
			case 4:	spider->set_speed(spider,-2,0);	break;
			case 5:	spider->set_speed(spider,0,0);	break;
			case 2:	spider->set_speed(spider,0,-2);	break;
			case 8:	spider->set_speed(spider,0,2);	 break;
			case 6: spider->set_speed(spider,2,0); break;
			default:
				spider->set_speed(spider,0,0); break;
		}
		
		//start a new game
		if (objects_overlap(ballcopy,creature)){
			win=1;
			break;
		}
		
		
		if (spider_outside_area(creature)){
			win=0;
			break;
		}
		
		
		delay_milli(20);
		
		
		

	}
	
	char *s;
	char winmessage[]="You Win!";
	char losemessage[]="Game Over";
	
	app_init();
	ascii_init();
	ascii_gotoxy(1,1);
	
	
	if (win){
			s = winmessage;
		//ascii rutin för att skriva "You Win" till display.
		while (*s)
			ascii_write_char(*s++);
		
	} else {
			s = losemessage;
		//ascii rutin för att skriva "Game Over" till display.
		while (*s)
			ascii_write_char(*s++);

		
		
	}

	
	

}








































