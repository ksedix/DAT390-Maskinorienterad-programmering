/*
 * 	startup.c
 *
 */
 
 //5.11
 
 
 #include <stdio.h>
#include <stdlib.h>
 
 
 
__attribute__((naked)) __attribute__((section (".start_section")) )
void startup ( void )
{
__asm__ volatile(" LDR R0,=0x2001C000\n");		/* set stack */
__asm__ volatile(" MOV SP,R0\n");
__asm__ volatile(" BL main\n");					/* call main */
__asm__ volatile(".L1: B .L1\n");				/* never return */
}


#define	SysTick	0xE000E010
#define STK_CTRL	((unsigned int*) SysTick)
#define STK_LOAD	((unsigned int*) SysTick+4)
#define STK_VAL	((unsigned int*) SysTick+8)


#define SIMULATOR    





//creates a delay of 250ns using systick
void delay_250ns(){
	
	*STK_CTRL=0;  //återställ systick
	*STK_LOAD=42;  //ladda räknaren med värdet 42;
	*STK_VAL=0;		//nollställ systick val.
	
	
	//varför ska man sätta bit 2 till 1? det gör ingen skillnad.
	*STK_CTRL=5;   //starta räknaren
	if (0x10000 & *STK_CTRL){
		return;
	}
	
	
	
	
	
}

void delay_mikro(unsigned int us){
	
	#ifdef SIMULATOR
	us/=250;
	us++;
	#endif
	
	int repeat=4*us;
	
	for (int i=0;i<repeat;i++){
		delay_250ns();
	}
	
}


void delay_milli(unsigned int ms){
	
	#ifdef SIMULATOR
	ms/=250;
	#endif
	
	//1 millisekund är 1000 mikrosekunder
	int repeat=1000*ms;
	
	for (int i=0;i<repeat;i++){
		delay_mikro(1);
	}

	
}


__attribute__((naked))
void graphic_initialize(void)
{
	__asm volatile (".HWORD	0xDFF0\n");
	__asm volatile (" BX LR\n");
}


__attribute__((naked))
void graphic_pixel_set(int x, int y)
{
	__asm volatile (".HWORD	0xDFF2\n");
	__asm volatile (" BX LR\n");
}

__attribute__((naked))
void graphic_clear_screen(void)
{
	__asm volatile (".HWORD	0xDFF1\n");
	__asm volatile (" BX LR\n");
}

__attribute__((naked))
void graphic_pixel_clear(int x, int y)
{
	__asm volatile (".HWORD	0xDFF3\n");
	__asm volatile (" BX LR\n");
}



typedef struct
{
	char x,y;
} POINT,*PPOINT;

typedef struct
{
	POINT p0,p1;
} LINE, *PLINE;

LINE lines[]=
{
	{40,10,100,10},
	{40,10,100,20},
	{40,10,100,30},
	{40,10,100,40},
	{40,10,100,50},
	{40,10,100,60},
	{40,10,90,60},
	{40,10,80,60},
	{40,10,70,60},
	{40,10,60,60},
	{40,10,50,60},
	{40,10,40,60}
	
};


//du får själv definiera hjälpfunktionen swap();

void swap(char* x, char* y){
	
	int xvalue=*x;
	
	*x=*y;
	*y=xvalue;
	
	
}



//det är något fel med draw_line funktionen, mer specifikt, algoritmen för att rita en linje

// använder graphic_pixel_set för att rita en linje.
void draw_line(PLINE line){
	
	//pointer till en line
	
	int y,x,error,deltax,deltay,ystep;

	int x0= line->p0.x;
	int y0= line->p0.y;
	int x1= line->p1.x;
	int y1= line->p1.y;
	
	
	int step;
	
	if (abs(y1-y0)  > abs(x1-x0)){
		step=1;
	} else {
		step=0;
	}
	
	if (step){
		swap(&x0,&y0);
		swap(&x1,&y1);
	}
	
	//so far correct.
	
	if (x0>x1){
		swap(&x0,&x1);
		swap(&y0,&y1);
	}
	
	//so far correct.
	
	deltax=x1-x0;
	deltay=abs(y1-y0);
	error=0;
	y=y0;
	
	
	if (y0<y1){
		ystep=1;
	} else {
		ystep=-1;
	}
	
	//so far correct.
	


	for (x=x0;x<x1;x++){
		if (step){
			graphic_pixel_set(y,x);
		} else {
			graphic_pixel_set(x,y);
		}
		error=error+deltay;
		if (2*error>=deltax){
			y=y+ystep;
			error=error-deltax;
		}
	
	
}  
}




//det finns en bug. när i blir 8 så ritas linjen fel.



void main(void)
{
	
	
	graphic_initialize();
	graphic_clear_screen();
	while(1){
		for (int i=0;i<sizeof(lines)/sizeof(LINE);i++){
			draw_line(&lines[i]);                                   //why do they need to use the adress operator?
			delay_milli(500);
		}
		graphic_clear_screen();
	}
	
	
	

}

