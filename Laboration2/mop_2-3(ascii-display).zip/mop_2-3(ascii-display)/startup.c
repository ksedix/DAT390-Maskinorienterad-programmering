/*
 * 	startup.c
 *
 */
 
#define PORT_E	0x40021000
#define GPIOE_MODER	((unsigned int*) PORT_E)
#define GPIOE_OTYPER	((unsigned short*)(PORT_E+4))
#define GPIOE_OSPEEDR	((unsigned int*)PORT_E+8)
#define GPIOE_PUPDR	((unsigned int*)PORT_E+0xC)
#define SIMULATOR

//byte-adresser för data och styrregister som LCD-display ska anslutas till.
#define GPIOE_IDRLOW	((unsigned char*)(PORT_E + 0x10))
#define GPIOE_IDRHIGH	((unsigned char*)(PORT_E + 0x11))
#define GPIOE_ODRLOW	((unsigned char*)(PORT_E + 0x14))
#define GPIOE_ODRHIGH	((unsigned char*)(PORT_E + 0x15))


//SysTick
#define	SysTick	0xE000E010
#define STK_CTRL	((unsigned int*) SysTick)
#define STK_LOAD	((unsigned int*) SysTick+4)
#define STK_VAL	((unsigned int*) SysTick+8)


//bitar i styrregistret hos display-modul.
#define B_E	0x40
#define B_SELECT	4
#define B_RW	2
#define B_RS	1
 
 
 
 
__attribute__((naked)) __attribute__((section (".start_section")) )
void startup ( void )
{
__asm__ volatile(" LDR R0,=0x2001C000\n");		/* set stack */
__asm__ volatile(" MOV SP,R0\n");
__asm__ volatile(" BL main\n");					/* call main */
__asm__ volatile(".L1: B .L1\n");				/* never return */
}



void init_app(void){
	
	*GPIOE_MODER=0x55555555;
	
}


//korrekt ✅
//creates a delay of 250ns using systick
void delay_250ns(){
	
	*STK_CTRL=0;  //återställ systick
	*STK_LOAD=42;  //ladda räknaren med värdet 42;
	*STK_VAL=0;		//nollställ systick val.
	
	
	//varför ska man sätta bit 2 till 1? det är för att räknaren ska räkna med 168MHZ.
	*STK_CTRL=5;   //starta räknaren
	
	
	
	//while-loop
	while (0x10000 & *STK_CTRL == 0);
	
	*STK_CTRL=0;
	
}



//korrekt ✅
void delay_mikro(unsigned int us){
	
	#ifdef SIMULATOR
	us/=250;
	us++;
	#endif
	
	int repeat=4*us;
	
	for (int i=0;i<repeat;i++){
		delay_250ns();
	}
	
}



//korrekt ✅
void delay_milli(unsigned int ms){
	
	#ifdef SIMULATOR
	ms/=250;
	ms++;
	#endif
	
	//1 millisekund är 1000 mikrosekunder
	int repeat=1000*ms;
	
	for (int i=0;i<repeat;i++){
		delay_mikro(1);
	}

	
}



//korrekt ✅


//ettställ bitar i styrregistret
void ascii_ctrl_bit_set(unsigned char x){
	
	
	*GPIOE_ODRLOW= *GPIOE_ODRLOW | x | B_SELECT ;
	
	
}



//korrekt ✅



//nollställ bitar i styrregistret
void ascii_ctrl_bit_clear(unsigned char x){
	
	unsigned char c= *GPIOE_ODRLOW & ~x;
	*GPIOE_ODRLOW= c | B_SELECT;
	
	
}



//korrekt ✅
//funktion för att skriva till ascii-displayen.
void ascii_write_controller(unsigned char command){
	
	delay_250ns();
	ascii_ctrl_bit_set(B_E);             //sätt E till 1(positiv flank) för att starta skrivcykeln.
	*GPIOE_ODRHIGH=command;
	delay_250ns();
	ascii_ctrl_bit_clear(B_E);          //sätt E till 0(negativ flank) för att avsluta skrivcykeln.
	
}



//korrekt ✅
//funktion för att skriva kommando till ascii-displayen.
void ascii_write_cmd(unsigned char command){
	
	//sätt RW till 0 och RS till 0 för att skriva kommando.
	ascii_ctrl_bit_clear(B_RS);
	ascii_ctrl_bit_clear(B_RW);               
	ascii_write_controller(command);
	
}



//korrekt ✅
//funktion för att skriva data till ascii-displayen
void ascii_write_data(unsigned char data){
	
	
	//sätt RW till 0 och RS till 1 för att skriva data.
	ascii_ctrl_bit_clear(B_RW);
	ascii_ctrl_bit_set(B_RS);               
	ascii_write_controller(data);
	
}




//läser från ascii-displayen

//korrekt ✅
unsigned char ascii_read_controller(void){
	
	ascii_ctrl_bit_set(B_E);
	
	//jag kan inte få den till 360ns, eftersom min funktion delay_250ns är för stor. Är detta lösningen?
	delay_250ns();
	delay_250ns();
	
	//läs från dataregistret
	unsigned char rv= *GPIOE_IDRHIGH;
	
	
	//sätt bit E till 0.
	ascii_ctrl_bit_clear(B_E);
	
	return rv;
	
	
	
}


//läs data från ascii-displayen
//korrekt ✅
unsigned char ascii_read_data(){
	
	//sätt port E15-8 till ingång och E7-0 till utgång.
	*GPIOE_MODER=0x00005555;
	
	
	//sätt bit RW till 1 och bit RS till 1 för att läsa data
	ascii_ctrl_bit_set(B_RW);
	ascii_ctrl_bit_set(B_RS);
	
	unsigned char rv= ascii_read_controller();
	
	*GPIOE_MODER=0x55555555;
	
	return rv;
	
}


//korrekt ✅
unsigned char ascii_read_status(){
	
	//sätt port E15-8 (dataregistret) till ingång
	*GPIOE_MODER=0x00005555;
	
	
	//sätt bit RW till 1 och bit RS till 0 för att läsa status.
	ascii_ctrl_bit_clear(B_RS);
	ascii_ctrl_bit_set(B_RW);
	
	unsigned char rv= ascii_read_controller();
	
	//sätt dataregistret som utgång
	*GPIOE_MODER=0x55555555;
	
	return rv;
	
	
	
}




//funktion för att skriva kommando


//korrekt✅
void ascii_command(command){
	
	while((ascii_read_status() & 0x80)==0x80);
	delay_mikro(8);
	ascii_write_cmd(command);
	delay_milli(2);
	
	//fördröj specifik fördröjning? vad menas?
	
}



//korrekt✅
void ascii_init(void){
	
	//Function Set
	ascii_command(00111000);
	
	//Display control, display på, markör på, konstant visning
	ascii_command(00001110);
	
	//Clear display
	ascii_command(1);
	
	//Entry Mode Set. adressering med increment. inget skift av adressbufferten.
	ascii_command(000000110);
	
	
}


//korrekt✅
void ascii_gotoxy(char x,char y){
	
	char adress=x-1;
	if (y==2){
		adress=adress+0x40;
	}
	ascii_write_cmd(0x80|adress);
	
}


//korrekt✅
void ascii_write_char(unsigned char c){
	
	while(ascii_read_status() & 0x80==0x80);
	
	delay_mikro(8);
	
	ascii_write_data(c);
	
	delay_mikro(50);
	

}































void main(void)
{
	
	char *s;

	char test1[] = "Alfanumerisk ";
	char test2[] = "Display - test";
	
	
	init_app();
	ascii_init();
	ascii_gotoxy(1,1);
	s=test1;
	while (*s){
		ascii_write_char(*s++);
	}
	ascii_gotoxy(1,2);
	s=test2;
	while( *s ){
		ascii_write_char(*s++);
	}
	return 0;
	
	
	
	
}


















































