#include <stdio.h>


void startup(){
	
	//portadresser
	STK_CTRL=*((unsigned long*) 0xE000E010);
	STK_LOAD=*((unsigned long*) 0xE000E014);
	STK_VAL=*((unsigned long*) 0xE000E018);
	
	
	
}

//funktion som använder sig av systick för att skapa fördröjning på 250ns. 
//MD407 har klockfrekvens på 168MHz
void delay_250ns(){
	
	//återställ systick
	STK_CTRL=0;
	
	//ladda räknaren med värdet
	STK_LOAD=42;
	
	
	
	
	
}

void delay_mikro(unsigned int us){
	
}


void delay_milli( unsigned int ms){
	
}







int main(int argc, char **argv)
{
	printf("hello world\n");
	return 0;
}
