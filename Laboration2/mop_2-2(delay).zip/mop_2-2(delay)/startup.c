/*
 * 	startup.c
 *
 */
__attribute__((naked)) __attribute__((section (".start_section")) )
void startup ( void )
{
__asm__ volatile(" LDR R0,=0x2001C000\n");		/* set stack */
__asm__ volatile(" MOV SP,R0\n");
__asm__ volatile(" BL main\n");					/* call main */
__asm__ volatile(".L1: B .L1\n");				/* never return */
}

#define	SysTick	0xE000E010
#define STK_CTRL	((unsigned int*) SysTick)
#define STK_LOAD	((unsigned int*) SysTick+4)
#define STK_VAL	((unsigned int*) SysTick+8)


#define portE 0x40021000
#define GPIOE_MODER	((unsigned short*) portE)
#define Bargraph *((unsigned char*) (portE+0x14))

#define SIMULATOR    


//creates a delay of 250ns using systick
void delay_250ns(){
	
	*STK_CTRL=0;  //återställ systick
	*STK_LOAD=42;  //ladda räknaren med värdet 42;
	*STK_VAL=0;		//nollställ systick val.
	
	
	//varför ska man sätta bit 2 till 1? det gör ingen skillnad.
	*STK_CTRL=5;   //starta räknaren
	if (0x10000 & *STK_CTRL){
		return;
	}
	
	
	
	
	
}

void delay_mikro(unsigned int us){
	
	#ifdef SIMULATOR
	us/=250;
	us++;
	#endif
	
	int repeat=4*us;
	
	for (int i=0;i<repeat;i++){
		delay_250ns();
	}
	
}


void delay_milli(unsigned int ms){
	
	#ifdef SIMULATOR
	ms/=250;
	#endif
	
	//1 millisekund är 1000 mikrosekunder
	int repeat=1000*ms;
	
	for (int i=0;i<repeat;i++){
		delay_mikro();
	}

	
}

void init_app(){
	
	//konfigurera port E0-7 som output.
	*GPIOE_MODER=0x5555;
}



void main(void)
{
	
	init_app();
	while(1){
		
		Bargraph=0;
		delay_milli(500);
		Bargraph=0xFF;
		delay_milli(500);
		
	}
		
	
	
}


//om man har definierat simulator som true så kommer den blinka snabbare. ja, detta stämmer. men simulatorn är långsammare än den verkliga datorn.
