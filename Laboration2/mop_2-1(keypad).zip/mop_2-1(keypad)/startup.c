/*
 * 	startup.c
 *
 */
__attribute__((naked)) __attribute__((section (".start_section")) )
void startup ( void )
{
__asm__ volatile(" LDR R0,=0x2001C000\n");		/* set stack */
__asm__ volatile(" MOV SP,R0\n");
__asm__ volatile(" BL main\n");					/* call main */
__asm__ volatile(".L1: B .L1\n");				/* never return */
}


#define GPIOD	0x40020C00
#define GPIOD_MODER ((unsigned int*) GPIOD)
#define GPIOD_IDR	((unsigned short*)	(GPIOD+0x10))
#define GPIOD_IDR_HIGH	((unsigned char*) (GPIOD+0x11))
#define GPIOD_ODR	((unsigned short*) (GPIOD+0x14))
#define GPIOD_ODR_HIGH	((unsigned char*) (GPIOD+0x15))
#define GPIOD_OTYPER	((unsigned short*) (GPIOD+4))
#define GPIOD_PUPDR		((unsigned int*) (GPIOD+0xC))
#define GPIOD_PUPDR_HIGH	((unsigned short*) (GPIOD+0xE))




void app_init(void){
	
	//Konfigurering av GPIO D-portens register med en keypad ansluten till pinnar D8-15 och 7segmentsdisplay ansluten till pinnar D0-7.
	
	//GPIO_MODER konfig
	// bit 31-16 konfigurerar keypad. bit 15-0 används för konfigurera output till 7segmentsdisplay.
	*GPIOD_MODER=0x55005555;
	
	//konfigurera push-pull på utpinnarna till keypad och på utpinnarna till 7segdisplay
	*GPIOD_OTYPER=0x0000; 
	
	//konfigurera pull-down på inpinnarna till keypad.
	*GPIOD_PUPDR_HIGH=0b10101010;
	
}


void ActivateRow(unsigned int row){
	
	
//sätter output pin(4 output pins) till 1 för den raden som ska aktiveras.
	
	switch(row){
		case 1: *GPIOD_ODR_HIGH=0x10;
		break;
		case 2: *GPIOD_ODR_HIGH=0x20;
		break;
		case 3: *GPIOD_ODR_HIGH=0x40;
		break;
		case 4: *GPIOD_ODR_HIGH=0x80;
		break;
		default:
		*GPIOD_ODR_HIGH=0;
		break;
	}
}



//läser av vilken kolumn som är tryckt. kommer endast funka om raden också är aktiv.
int ReadColumn(){
	
	//check if the row is active by reading the Input data register of port D. 
	
	if (*GPIOD_IDR_HIGH & 8){
		return 4;
	} 
	if (*GPIOD_IDR_HIGH & 4){
		return 3;
	}
	if (*GPIOD_IDR_HIGH & 2){
		return 2;
	}
	if (*GPIOD_IDR_HIGH & 1){
		return 1;
	}
	return 0;
	
}


unsigned char keyb(void){
		
		int row,col;
		unsigned char keycode;
		unsigned char keycodes[4][4]={{1,2,3,0xA},{4,5,6,0xB},{7,8,9,0xC},{0xE,0,0xF,0xD}};
		
		for (row=1;row<=4;row++){
			ActivateRow(row);
			col=ReadColumn();
			if (col!=0) {
				keycode= keycodes[row-1][col-1];
				ActivateRow(0);
				return keycode;
			}
			
			}
			keycode=0xFF;
			ActivateRow(0);
			return keycode;
		
	}

	//convert the keycode to a segment code
	void out7seg(unsigned char keycode){
		
		//an ordered array of all segment codes starting from 0-15.
		unsigned char segmentcodes[]={0b00111111,0b00000110,0b01011011,0b01001111,0b01100110,0b01101101,0b01111101,0b00000111,0b01111111,0b01100111,0b01110111,0b01111100,0b00111001,0b01011110,0b01111001,0b01110001 };
		
		//if keycode is 0-15
		if (keycode>=0 && keycode<0x10){
		unsigned char segmentcode=segmentcodes[keycode];
		
		//segmentkoden skrivs till displayen port d pinnar 0-7
		*GPIOD_ODR=segmentcode;
		
		} else {
			
			//displayen släcks om ogilltig keycode.
			*GPIOD_ODR=0x0000;
		}

	}
	
	
	
	
	



int main(int argc, char **argv)
{
	
	
	
	app_init();
	
	while(1){
		//*GPIOD_ODR=0b00000111;
		out7seg(keyb());
	}
	

	return 0;
}
