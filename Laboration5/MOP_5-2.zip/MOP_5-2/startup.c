//detta är ett enkelt pong spel där användaren spelaren pong mot datorn. Grafisk display
//används för spelet samt ascii display för att skriva "game over" eller "You win".
//spelet har blivit långsamt pågrund av ball_collision funktionen, men det är 
//inget jag kan kontrollera.





#include <stdio.h>
#include <stdlib.h>
//#include <libmd407.h>    //programmet blir väldigt långsamt när jag inkluderar biblioteket. därför gör jag utan biblioteket.    
#include <mop5_2.h>



__attribute__((naked)) __attribute__((section (".start_section")) )
void startup ( void )
{
__asm__ volatile(" LDR R0,=0x2001C000\n");		/* set stack */
__asm__ volatile(" MOV SP,R0\n");
__asm__ volatile(" BL main\n");					/* call main */
__asm__ volatile(".L1: B .L1\n");				/* never return */
}

//skapad av Mirco Ghadri

GEOMETRY ball_geometry=
{
	
	12,
	4,4,
	{
		{0,1},{0,2},{1,0},{1,1},{1,2},{1,3},{2,0},{2,1},{2,2},{2,3},{3,1},{3,2}
	}
	
	
	
};

//vi skapar våran boll som vi kommer använda


GEOMETRY racket_geometry= {
	
	27,    //antalet punkter
	5,9,   //x och y bredd
	
	{
		
		{0,0},{0,1},{0,2},{0,3},{0,4},{0,5},{0,6},{0,7},{0,8},{4,0},{4,1},{4,2},{4,3},{4,4},{4,5},{4,6},{4,7},{4,8},
		{1,0},{2,0},{3,0},{1,8},{2,8},{3,8},
		{2,3},{2,4},{2,5}
		
	}
	
		
};



static OBJECT ballobject=
{
	
	&ball_geometry,
	-2,1,
	120,35,
	draw_object,
	clear_object,
	move_object,
	set_object_speed
	
};



static OBJECT racket_object1= 
{
	&racket_geometry,
	0,0,
	1,32,
	draw_object,
	clear_object,
	move_object,
	set_object_speed
};


static OBJECT racket_object2= 
{
	&racket_geometry,
	0,4,
	123,32,
	draw_object,
	clear_object,
	move_object,
	set_object_speed
};




//projektet fungerar men bollen uppdateras inte så ofta. kolla hur det set ut för roger.

void main(void)
{
	
	//konfigurera keypad och grafisk display för användning.
	init_app();
	//ascii_init();
	
	graphic_initialize();
	graphic_clear_screen();
	
	
	char c;
	int lose=0;
	int win=0;
	
	//skapa en pekare till bollobjektet.
	POBJECT ball=&ballobject;
	POBJECT racket1=&racket_object1;
	POBJECT racket2=&racket_object2;
	
	
	while(1){
		
		ball->move(ball);
		racket1->move(racket1);
		racket2->move(racket2);
		//delay_milli(20);
		c=keyb();
		
		switch(c){
			case 5:	racket1->set_speed(racket1,0,0);	break;
			case 2:	racket1->set_speed(racket1,0,-3);	break;
			case 8:	racket1->set_speed(racket1,0,3);	 break;
		}
		
		
		//dessa funktioner (ball_collision) gör att programmet blir mycket långsammare. Det är inget jag kan ändra.
		if (ball_collision(ball,racket1)){
			ball->dirx*=-1;
		}
		if (ball_collision(ball,racket2)){
			ball->dirx*=-1;
		}
		
		
		if (ball->posx<0){
			lose=1;
		}
		if (ball->posx+ball->geo->sizex>128){
			win=1;
		}
		 
		
		char *s;
		char losemessage[]="Game Over";
		char winmessage[]="You Win!";
		
		//position the cursor
		ascii_gotoxy(1,1);
	
	
		if (lose){
			s = losemessage;
		//ascii rutin för att skriva "You Win" till display.
		while (*s)
			ascii_write_char(*s++);
		break;  //avsluta spelet.
		} 
		if (win){
			s = winmessage;
			while (*s)
				ascii_write_char(*s++);
			break;  //avsluta spelet.
		}
		
	}
	
	
	
	
	

}