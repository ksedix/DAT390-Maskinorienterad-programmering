
//skapad av Mirco Ghadri

#define GPIOD	0x40020C00
#define GPIOD_MODER ((unsigned int*) GPIOD)
#define GPIOD_IDR	((unsigned short*)	(GPIOD+0x10))
#define GPIOD_IDR_HIGH	((unsigned char*) (GPIOD+0x11))
#define GPIOD_ODR	((unsigned short*) (GPIOD+0x14))
#define GPIOD_ODR_HIGH	((unsigned char*) (GPIOD+0x15))
#define GPIOD_OTYPER	((unsigned short*) (GPIOD+4))
#define GPIOD_PUPDR		((unsigned int*) (GPIOD+0xC))
#define GPIOD_PUPDR_HIGH	((unsigned short*) (GPIOD+0xE))



#define PORT_E	0x40021000
#define GPIOE_MODER	((unsigned int*) PORT_E)
#define GPIOE_OTYPER	((unsigned short*)(PORT_E+4))
#define GPIOE_OSPEEDR	((unsigned int*)PORT_E+8)
#define GPIOE_PUPDR	((unsigned int*)PORT_E+0xC)
#define SIMULATOR

//byte-adresser för data och styrregister som LCD-display ska anslutas till.
#define GPIOE_IDRLOW	((unsigned char*)(PORT_E + 0x10))
#define GPIOE_IDRHIGH	((unsigned char*)(PORT_E + 0x11))
#define GPIOE_ODRLOW	((unsigned char*)(PORT_E + 0x14))
#define GPIOE_ODRHIGH	((unsigned char*)(PORT_E + 0x15))


//SysTick
#define	SysTick	0xE000E010
#define STK_CTRL	((unsigned int*) SysTick)
#define STK_LOAD	((unsigned int*) SysTick+4)
#define STK_VAL	((unsigned int*) SysTick+8)


//bitar i styrregistret hos display-modul.
#define B_E	0x40
#define B_SELECT	4
#define B_RW	2
#define B_RS	1
 
 

#define MAX_POINTS 30
#define SIMULATOR


void delay_250ns(){
	
	*STK_CTRL=0;  //återställ systick
	*STK_LOAD=42;  //ladda räknaren med värdet 42;
	*STK_VAL=0;		//nollställ systick val.
	
	
	//varför ska man sätta bit 2 till 1? det är för att räknaren ska räkna med 168MHZ.
	*STK_CTRL=5;   //starta räknaren
	
	
	
	//while-loop
	while (0x10000 & *STK_CTRL == 0);
	
	*STK_CTRL=0;
	
}



//korrekt ✅
void delay_mikro(unsigned int us){
	
	#ifdef SIMULATOR
	us/=1000;
	us++;
	#endif
	
	int repeat=4*us;
	
	for (int i=0;i<repeat;i++){
		delay_250ns();
	}
	
}



void delay_milli(unsigned int ms){
	
	#ifdef SIMULATOR
	ms/=1000;
	ms++;
	#endif
	
	//1 millisekund är 1000 mikrosekunder
	int repeat=1000*ms;
	
	for (int i=0;i<repeat;i++){
		delay_mikro(1);
	}
	
}




void init_app(){
	
	//Konfigurering av GPIO D-portens register med en keypad ansluten till pinnar D8-15 och 7segmentsdisplay ansluten till pinnar D0-7.
	
	//GPIO_MODER konfig
	// bit 31-16 konfigurerar keypad. bit 15-0 används för konfigurera output till 7segmentsdisplay.
	*GPIOD_MODER=0x55005555;
	
	//konfigurera push-pull på utpinnarna till keypad och på utpinnarna till 7segdisplay
	*GPIOD_OTYPER=0x0000; 
	
	//konfigurera pull-down på inpinnarna till keypad.
	*GPIOD_PUPDR_HIGH=0b10101010;
	
	//konfigurering av PORT E
	*GPIOE_MODER=0x55555555;
	
	
	
	
}




void ActivateRow(unsigned int row){
	
	
//sätter output pin(4 output pins) till 1 för den raden som ska aktiveras.
	
	switch(row){
		case 1: *GPIOD_ODR_HIGH=0x10;
		break;
		case 2: *GPIOD_ODR_HIGH=0x20;
		break;
		case 3: *GPIOD_ODR_HIGH=0x40;
		break;
		case 4: *GPIOD_ODR_HIGH=0x80;
		break;
		default:
		*GPIOD_ODR_HIGH=0;
		break;
	}
}



//läser av vilken kolumn som är tryckt. kommer endast funka om raden också är aktiv.
int ReadColumn(){
	
	//check if the row is active by reading the Input data register of port D. 
	
	if (*GPIOD_IDR_HIGH & 8){
		return 4;
	} 
	if (*GPIOD_IDR_HIGH & 4){
		return 3;
	}
	if (*GPIOD_IDR_HIGH & 2){
		return 2;
	}
	if (*GPIOD_IDR_HIGH & 1){
		return 1;
	}
	return 0;
	
}


unsigned char keyb(void){
		
		int row,col;
		unsigned char keycode;
		unsigned char keycodes[4][4]={{1,2,3,0xA},{4,5,6,0xB},{7,8,9,0xC},{0xE,0,0xF,0xD}};
		
		for (row=1;row<=4;row++){
			ActivateRow(row);
			col=ReadColumn();
			if (col!=0) {
				keycode= keycodes[row-1][col-1];
				ActivateRow(0);
				return keycode;
			}
			
			}
			keycode=0xFF;
			ActivateRow(0);
			return keycode;
		
	}

	//convert the keycode to a segment code
	void out7seg(unsigned char keycode){
		
		//an ordered array of all segment codes starting from 0-15.
		unsigned char segmentcodes[]={0b00111111,0b00000110,0b01011011,0b01001111,0b01100110,0b01101101,0b01111101,0b00000111,0b01111111,0b01100111,0b01110111,0b01111100,0b00111001,0b01011110,0b01111001,0b01110001 };
		
		//if keycode is 0-15
		if (keycode>=0 && keycode<0x10){
		unsigned char segmentcode=segmentcodes[keycode];
		
		//segmentkoden skrivs till displayen port d pinnar 0-7
		*GPIOD_ODR=segmentcode;
		
		} else {
			
			//displayen släcks om ogilltig keycode.
			*GPIOD_ODR=0x0000;
		}

	}
	


//ASCII DISPLAY FUNKTIONER..


//korrekt ✅


//ettställ bitar i styrregistret
void ascii_ctrl_bit_set(unsigned char x){
	
	
	*GPIOE_ODRLOW= *GPIOE_ODRLOW | x | B_SELECT ;
	
	
}



//korrekt ✅



//nollställ bitar i styrregistret
void ascii_ctrl_bit_clear(unsigned char x){
	
	unsigned char c= *GPIOE_ODRLOW & ~x;
	*GPIOE_ODRLOW= c | B_SELECT;
	
	
}



//korrekt ✅
//funktion för att skriva till ascii-displayen.
void ascii_write_controller(unsigned char command){
	
	delay_250ns();
	ascii_ctrl_bit_set(B_E);             //sätt E till 1(positiv flank) för att starta skrivcykeln.
	*GPIOE_ODRHIGH=command;
	delay_250ns();
	ascii_ctrl_bit_clear(B_E);          //sätt E till 0(negativ flank) för att avsluta skrivcykeln.
	
}



//korrekt ✅
//funktion för att skriva kommando till ascii-displayen.
void ascii_write_cmd(unsigned char command){
	
	//sätt RW till 0 och RS till 0 för att skriva kommando.
	ascii_ctrl_bit_clear(B_RS);
	ascii_ctrl_bit_clear(B_RW);               
	ascii_write_controller(command);
	
}



//korrekt ✅
//funktion för att skriva data till ascii-displayen
void ascii_write_data(unsigned char data){
	
	
	//sätt RW till 0 och RS till 1 för att skriva data.
	ascii_ctrl_bit_clear(B_RW);
	ascii_ctrl_bit_set(B_RS);               
	ascii_write_controller(data);
	
}




//läser från ascii-displayen

//korrekt ✅
unsigned char ascii_read_controller(void){
	
	ascii_ctrl_bit_set(B_E);
	
	//jag kan inte få den till 360ns, eftersom min funktion delay_250ns är för stor. Är detta lösningen?
	delay_250ns();
	delay_250ns();
	
	//läs från dataregistret
	unsigned char rv= *GPIOE_IDRHIGH;
	
	
	//sätt bit E till 0.
	ascii_ctrl_bit_clear(B_E);
	
	return rv;
	
	
	
}


//läs data från ascii-displayen
//korrekt ✅
unsigned char ascii_read_data(){
	
	//sätt port E15-8 till ingång och E7-0 till utgång.
	*GPIOE_MODER=0x00005555;
	
	
	//sätt bit RW till 1 och bit RS till 1 för att läsa data
	ascii_ctrl_bit_set(B_RW);
	ascii_ctrl_bit_set(B_RS);
	
	unsigned char rv= ascii_read_controller();
	
	*GPIOE_MODER=0x55555555;
	
	return rv;
	
}


//korrekt ✅
unsigned char ascii_read_status(){
	
	//sätt port E15-8 (dataregistret) till ingång
	*GPIOE_MODER=0x00005555;
	
	
	//sätt bit RW till 1 och bit RS till 0 för att läsa status.
	ascii_ctrl_bit_clear(B_RS);
	ascii_ctrl_bit_set(B_RW);
	
	unsigned char rv= ascii_read_controller();
	
	//sätt dataregistret som utgång
	*GPIOE_MODER=0x55555555;
	
	return rv;
	
	
	
}


//funktion för att skriva kommando

//korrekt✅
void ascii_command(command){
	
	while((ascii_read_status() & 0x80)==0x80);
	delay_mikro(8);
	ascii_write_cmd(command);
	delay_milli(2);
	
	//fördröj specifik fördröjning? vad menas?
	
}



//korrekt✅
void ascii_init(void){
	
	//Function Set
	ascii_command(00111000);
	
	//Display control, display på, markör på, konstant visning
	ascii_command(00001110);
	
	//Clear display
	ascii_command(1);
	
	//Entry Mode Set. adressering med increment. inget skift av adressbufferten.
	ascii_command(000000110);
	
	
}


//korrekt✅
void ascii_gotoxy(char x,char y){
	
	char adress=x-1;
	if (y==2){
		adress=adress+0x40;
	}
	ascii_write_cmd(0x80|adress);
	
}


//korrekt✅
void ascii_write_char(unsigned char c){
	
	while(ascii_read_status() & 0x80==0x80);
	
	delay_mikro(8);
	
	ascii_write_data(c);
	
	delay_mikro(50);
	

}


__attribute__((naked))
void graphic_initialize(void)
{
	__asm volatile (".HWORD	0xDFF0\n");
	__asm volatile (" BX LR\n");
}


__attribute__((naked))
void graphic_pixel_set(int x, int y)
{
	__asm volatile (".HWORD	0xDFF2\n");
	__asm volatile (" BX LR\n");
}

__attribute__((naked))
void graphic_clear_screen(void)
{
	__asm volatile (".HWORD	0xDFF1\n");
	__asm volatile (" BX LR\n");
}

__attribute__((naked))
void graphic_pixel_clear(int x, int y)
{
	__asm volatile (".HWORD	0xDFF3\n");
	__asm volatile (" BX LR\n");
}


//strukturer vi använder//

typedef struct
{
	char x,y;
} POINT,*PPOINT;


typedef struct{
	
	int numpoints;
	int sizex;
	int sizey;
	
	//a list of points;
	POINT px[MAX_POINTS];
	
}	GEOMETRY, *PGEOMETRY;



typedef struct tObj{
	
	PGEOMETRY geo;
	int dirx,diry;
	int posx,posy;
	
	
	void (*draw) (struct tObj*);
	void (*clear) (struct tObj*);
	void (*move) (struct tObj*);
	void (*set_speed) (struct tObj*, int , int );
	
}	OBJECT, *POBJECT;




//draw a pixel where each point of the ballobject is located at
void draw_object(POBJECT o){
	
	//iterate through each point in the array.
	for (int i=0;i<o->geo->numpoints;i++){
	POINT p=o->geo->px[i];
	
	graphic_pixel_set(p.x+o->posx,p.y+o->posy);
	
	}
	
}

void clear_object(POBJECT o){
	
	//iterate through each point in the array.
	for (int i=0;i<o->geo->numpoints;i++){
	POINT p=o->geo->px[i];
	
	//addera den initiella koordinaten med nuvarande positionen för bollen.
	graphic_pixel_clear(p.x+o->posx,p.y+o->posy);
	
	
}
	
}


//rör bollen i objektets riktning.
void move_object(POBJECT o){
	
	//ta bort gamla positionen.
	o->clear(o);
	
	
	//studsa bollen mot upp-och ner väggarna. 
	if (o->posy-2<0){
		
		o->diry*=-1;
		
	}
	
	if ((o->posy+o->geo->sizey)>64){
		
		o->diry*=-1;
		
	}

	//addera riktningskoordinaterna
	o->posx+=o->dirx;
	o->posy+=o->diry;

	
	
	o->draw(o);

	
}
	

void set_object_speed(POBJECT o, int xspeed, int yspeed){
	
	o->dirx=xspeed;
	o->diry=yspeed;
	
}


int ball_collision(POBJECT o1, POBJECT o2){
	
	//check if the points on the objects ever collide.
	
	for (int i=0;i<(o1->geo->numpoints);i++){
		
		POINT p1= o1->geo->px[i];
		
		for (int j=0;j<(o2->geo->numpoints);j++){
			
			POINT p2= o2->geo->px[j];
			
			if ((p1.x+o1->posx)==(p2.x+o2->posx) && (p1.y+o1->posy)==(p2.y+o2->posy)){
				return 1;
			}
			
		}
		
	}
	return 0;
	
}
