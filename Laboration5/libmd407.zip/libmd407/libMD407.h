/*
*	libNAME.h
*	Declaration of library functions, constants etc...
*/




//måste man deklarera startup funktionerna från general.c här?

//placera funktionsdeklarationer för de egendefinierade funktionerna här.  s 189.

//GENERAL

void startup(void);
static char *heap_end;
char * _sbrk(int incr);
volatile static void _crt_init();
volatile static void _crt_init();

int _close(int file);
int _open(const char *name, int flags, int mode);
int _isatty(int file); 
int _fstat(int file, struct stat *st);
int _lseek(int file, int ptr, int dir); 
int _read(int file, char *ptr, int len);
int _write(int file, char *ptr, int len);




//KEYPAD----------------------------------------------------------------------------------------------------------------------------

//funktioner
void init_app_keyboard(void);
void ActivateRow(unsigned int row);
int ReadColumn();
unsigned char keyb(void);
void out7seg(unsigned char keycode);

//makron
#define GPIOD	0x40020C00
#define GPIOD_MODER ((unsigned int*) GPIOD)
#define GPIOD_IDR	((unsigned short*)	(GPIOD+0x10))
#define GPIOD_IDR_HIGH	((unsigned char*) (GPIOD+0x11))
#define GPIOD_ODR	((unsigned short*) (GPIOD+0x14))
#define GPIOD_ODR_HIGH	((unsigned char*) (GPIOD+0x15))
#define GPIOD_OTYPER	((unsigned short*) (GPIOD+4))
#define GPIOD_PUPDR		((unsigned int*) (GPIOD+0xC))
#define GPIOD_PUPDR_HIGH	((unsigned short*) (GPIOD+0xE))



//ASCII-DISPLAY----------------------------------------------------------------------------------------------------------------------------

//funktioner

void init_app_ascii(void);
void delay_250ns();
void delay_mikro(unsigned int us);
void delay_milli(unsigned int ms);
void ascii_ctrl_bit_set(unsigned char x);
void ascii_ctrl_bit_clear(unsigned char x);
void ascii_write_controller(unsigned char command);
void ascii_write_cmd(unsigned char command);
void ascii_write_data(unsigned char data);
unsigned char ascii_read_controller(void);
unsigned char ascii_read_data();
unsigned char ascii_read_status();
void ascii_command(command);
void ascii_init(void);
void ascii_gotoxy(char x,char y);
void ascii_write_char(unsigned char c);



//makron
#define PORT_E	0x40021000
#define GPIOE_MODER	((unsigned int*) PORT_E)
#define GPIOE_OTYPER	((unsigned short*)(PORT_E+4))
#define GPIOE_OSPEEDR	((unsigned int*)PORT_E+8)
#define GPIOE_PUPDR	((unsigned int*)PORT_E+0xC)
#define SIMULATOR

//byte-adresser för data och styrregister som LCD-display ska anslutas till.
#define GPIOE_IDRLOW	((unsigned char*)(PORT_E + 0x10))
#define GPIOE_IDRHIGH	((unsigned char*)(PORT_E + 0x11))
#define GPIOE_ODRLOW	((unsigned char*)(PORT_E + 0x14))
#define GPIOE_ODRHIGH	((unsigned char*)(PORT_E + 0x15))


//SysTick
#define	SysTick	0xE000E010
#define STK_CTRL	((unsigned int*) SysTick)
#define STK_LOAD	((unsigned int*) SysTick+4)
#define STK_VAL	((unsigned int*) SysTick+8)


//bitar i styrregistret hos display-modul.
#define B_E	0x40
#define B_SELECT	4
#define B_RW	2
#define B_RS	1
 


//USART- input/output till terminalen  ----------------------------------------------------------------------------------------------------------------------------



//funktioner

void init_app_usart();
void usart_irq_handler(void);
char usart_tstchar();
void usart_outchar( char c );
void putstring(char *s);


//makron
typedef struct {
	
	volatile unsigned short sr;
	volatile unsigned short Unused0;
	volatile unsigned short dr;
	volatile unsigned short Unused1;
	volatile unsigned short brr;
	volatile unsigned short Unused2;
	volatile unsigned short cr1;
	volatile unsigned short Unused3;
	volatile unsigned short cr2;
	volatile unsigned short Unused4;
	volatile unsigned short cr3;
	volatile unsigned short Unused5;
	volatile unsigned short gtpr;
	
	
} USART;


//MAKRON

#define SCB_VTOR	(volatile unsigned int *) 0xE000ED08


#define USART1	((USART*) 0x40011000)
#define USART1_IRQVEC	((void (**) (void)) 0x2001C0D4)

#define NVIC_USART1_ISER	((volatile unsigned int*) 0xE000E104 )
#define NVIC_USART1_IRQ_BPOS	(1<<5)

//bitar i kontrollregistet USART_CR1
#define BIT_UE	(1<<13)
#define BIT_TE	(1<<3)
#define BIT_RE	(1<<2)

//bitar i statusregistrert USART_SR
#define BIT_RXNE	(1<<5)
#define BIT_TXE		(1<<7)

#define BIT_TXEIE	(1<<7)         //TXE interrupt enable.
#define BIT_TCIE	(1<<6)

#define TXE	(1<<7)               //transmit data register empty
#define TC	(1<<6)               //transmission complete









































































































