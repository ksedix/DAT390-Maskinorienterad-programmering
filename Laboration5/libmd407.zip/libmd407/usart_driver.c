//USART driver används för input/output till terminalen.



#include	"libmd407.h"

inbuf=0;
outbuf=0;



void usart_irq_handler(void){
	
	
	
	if (USART1->sr & BIT_RXNE){
		inbuf= (char) USART1->dr;
	}
	
	
	
	//vi gör denna kontrollen eftersom avbrottsrutinen kan aktiveras av andra orsaker också. 
	if ( ((USART1->cr1 & BIT_TXEIE)!=0) && ((USART1->sr & BIT_TXE)!=0) ) 
	{
		
		USART1->dr = (unsigned short) outbuf;
		USART1->cr1 &= ~BIT_TXEIE;				//deaktivera avbrott för TXEIE
		
	}
	
	
	
}



void init_app_usart(){
	
	//relokera vektortabellen
	
	*SCB_VTOR= 0x2001C000;
	
	inbuf=0;
	
	*USART1_IRQVEC = usart_irq_handler;
	*NVIC_USART1_ISER |= NVIC_USART1_IRQ_BPOS;
	
	
	USART1->brr = 0x2D9;
	USART1->cr2 = 0;               //antalet stoppbitar;
	USART1->cr3 = 0;
	
	
	//aktivera kretsen
	USART1->cr1= BIT_UE | BIT_TE | BIT_RE;
	
}


char usart_tstchar(){
	
	char c = inbuf;
	inbuf=0;
	return c;
	
	
	
}










void usart_outchar( char c ){
	
	//vänta sålänge överföring sker
	outbuf=c;
	
	USART1->cr1 |= BIT_TXEIE;              //aktivera avbrott för TXE;
	
	
}



void putstring(char *s){
	
	while(*s){
		usart_outchar(*s++);
	}
	
	
}
