/*
 * 	startup.c
 *
 */
__attribute__((naked)) __attribute__((section (".start_section")) )
void startup ( void )
{
__asm__ volatile(" LDR R0,=0x2001C000\n");		/* set stack */
__asm__ volatile(" MOV SP,R0\n");
__asm__ volatile(" BL main\n");					/* call main */
__asm__ volatile(".L1: B .L1\n");				/* never return */
}



#define	SysTick	0xE000E010
#define STK_CTRL	((volatile unsigned int*) SysTick)
#define STK_LOAD	((volatile unsigned int*) (SysTick+4))
#define STK_VAL	((volatile unsigned int*) (SysTick+8))


#define SCB_VECTOR	((volatile unsigned long*) 0xE000ED08)



//GPIO port D

#define GPIOD	0x40020C00
#define GPIOD_MODER	((volatile unsigned int*) GPIOD)
#define GPIOD_ODR_LOW	((volatile unsigned char*) (GPIOD+0x14))
#define GPIOD_ODR_HIGH	((volatile unsigned char*) (GPIOD+0x15))

#define SIMULATOR

#ifdef SIMULATOR
#define DELAY_COUNT	100
#else
#define DELAY_COUNT	1000000
#endif



//this is correct ✅
void delay_1mikro(){
	
	*STK_CTRL=0;
	
	//ladda räknaren med värdet 42000 eftersom 1 nanosekunde kräver 42 iterationer.
	
	*STK_LOAD=167;     // delay nano var 250ns();
	
	*STK_VAL=0;
	*STK_CTRL=7;        //starta räknaren.
	
	
}



static volatile int systick_flag;
static volatile int delay_count;




//this is correct ✅
void delay (unsigned int count){
	
	
	if (count==0) {
		return;
	}
	delay_count=count;
	systick_flag=0;
	
	
	delay_1mikro();
	
	
	
}



//this is correct ✅
void systick_irq_handler(void)
{
	
	
	
	
	
	*STK_CTRL=0;
	delay_count -- ;
	if ( delay_count > 0 ) {
		delay_1mikro();
	} else	{
		
		systick_flag = 1; 
	}
	
	
	
	
	
	
}




//konfigurera port D som 


//this is correct ✅
void init_app(void)

{
	
	//initiera alla pinnar som utportar
	*GPIOD_MODER=0x55555555;
	
	//gå in i handler mode.
	
	//avbrottsvektorn innehåller vår handler-rutin.
	//du måste ändra avbrottsvektorn till write mode.
	
	
	
	*SCB_VECTOR=0x2001C000;
	
	* ( (void (**) (void)) 0x2001C03C) = systick_irq_handler;
	
	
	
	
	
}










//problemet med programmet är att avbrottsrutinen är blockerande fördröjning. Hur kan man undvika detta?


void main(void)
{
	
	init_app();
	unsigned char c=0;
	
	
	//bargraph som är kopplad till ODR_LOW ska släckas
	*GPIOD_ODR_LOW= 0;
	delay(DELAY_COUNT);
	
	//bargraph som är kopplad till ODR LOW ska tändas
	*GPIOD_ODR_LOW= 0xFF;
	
	while(1)
	{
		
		if (systick_flag)
			break;
		c++;
		*GPIOD_ODR_HIGH=c;
		
	}
	
	//släck lysdioden när fördröjningen är klar.
	*GPIOD_ODR_LOW=0;
	
	
	
	
}



























