/*
 * 	startup.c
 *
 */
__attribute__((naked)) __attribute__((section (".start_section")) )
void startup ( void )
{
__asm__ volatile(" LDR R0,=0x2001C000\n");		/* set stack */
__asm__ volatile(" MOV SP,R0\n");
__asm__ volatile(" BL main\n");					/* call main */
__asm__ volatile(".L1: B .L1\n");				/* never return */
}

//adresser för exti- register
#define SYSCFG	0x40013800
#define EXTICR1	((unsigned short*) (SYSCFG+0x8))
#define EXTICR2	((unsigned short*) (SYSCFG+0xC))
#define EXTICR3	((unsigned short*) (SYSCFG+0x10))
#define EXTICR4	((unsigned short*) (SYSCFG+0x14))

//adress för exti modul register
#define EXTI_MODULE	0x40013C00
#define EXTI_IMR	((unsigned int*) EXTI_MODULE)
#define EXTI_EMR	((unsigned int*) (EXTI_MODULE+0x4))
#define EXTI_RTSR	((unsigned int*) (EXTI_MODULE+0x8))
#define EXTI_FTSR	((unsigned int*) (EXTI_MODULE+0xC))
#define EXTI_SWIER	((unsigned int*) (EXTI_MODULE+0x10))
#define EXTI_PR		((unsigned int*) (EXTI_MODULE+0x14))

//NVIC- modul adresser.

#define NVIC_EXTI3_BPOS	(1<<9)
#define NVIC_ISER0	((unsigned int*) 0xE000E100)	


//port D

#define GPIOD	0x40020C00
#define GPIOD_MODER	((unsigned int*) GPIOD)
#define GPIOD_ODR_LOW	((unsigned int*) (GPIOD+0x14))


//PORT E adresser

#define GPIOE	0x40021000
#define GPIOE_MODER		((unsigned int*) 0x40021000)
#define GPIOE_IDR_LOW	((unsigned char*) 0x40021010)
#define GPIOE_ODR_LOW	((unsigned char*) 0x40021014)




//relokera vektortabellen genom att ändra värdet i SCB_VTOR registret.
#define SCB_VTOR	(volatile unsigned int*)	0xE000ED08




//FUNCTION DEFINITIONS

//räknar hur många avbrott som har genererats.
static int count=0;



void irq_handler(void){
	
	//kvittera avbrott från exti3; avbrott återställs genom att 1 skrivs till motsvarande bit i exit pending register.
	
	*EXTI_PR |=8;
	
	
	//1.om avbrott irq0.     detta funkar inte.
	
	int value= *GPIOE_IDR_LOW ; 
	
	if ((*GPIOE_IDR_LOW &1) == 1){
		
		//kvittera avbrott irq0
		
		//ettställ rst utan att påverka de andra bitarna
		*GPIOE_ODR_LOW |= (1<<4);
		//nollställ
		*GPIOE_ODR_LOW &= ~(1<<4);
		
		
		//inkrementera count
			
		count++;
	

	}
	
	
	//2. om avbrott irq1
	
	if ( (*GPIOE_IDR_LOW &2) == 2){
		
		//kvittera avbrott irq1
		
		//ettställ
		*GPIOE_ODR_LOW |= (1<<5);
		
		//nollställ
		*GPIOE_ODR_LOW &= ~(1<<5);
		

		count=0;
		
		
	}

	
	//3. om avbrott irq2
	
	if ((*GPIOE_IDR_LOW & (1<<3)) == (1<<3) ){
	
		
	//kvittera avbrott irq2
	
	*GPIOE_ODR_LOW |=(1<<6);
	*GPIOE_ODR_LOW &= ~(1<<6);
	
	
	
	//om diodramp är tänd, släck alla:  0;
	//om diodramp är släckt, tänd alla: 0xFF;
	if (*GPIOD_ODR_LOW==0){
		*GPIOD_ODR_LOW=0xFF;
	} else {
		*GPIOD_ODR_LOW=0;
	}
		
		
		
		
		
		
		
	}

	
	
	
	
	
	
	
};











//initiera avbrottsvektorn och port D för display

void app_init(){
	
	//konfigurera pinnar 0-7 som utport.
	*GPIOD_MODER=0x00005555;
	
	//konfigurera PE4 och PE7 som utport och PE0 och PE3 som inport.
	*GPIOE_MODER=0x00005500;
	
	//Koppla PE3 till avbrottslina EXTI3;
	*EXTICR1 &=0x0FFF;
	*EXTICR1 |=0x4000;
	
	//konfigurera exti3 för att generera avbrott, detta görs i exti modulen
	
	*EXTI_IMR |= 8;
	*EXTI_RTSR |=8;
	*EXTI_FTSR	&=~8;
	
	//relokera vektortabellen till läs och skrivbart minne.
	*SCB_VTOR = 0x2001C000;
	*((void	(**)  (void)) (*SCB_VTOR+0x64)) = irq_handler;
	
	//konfigurera de bitar i NVIC som kontrollerar den avbrottslina som exti3 är kopplad till. vi använder nvic iser0 eftersom biten är i intervallet 0-31.
	
	*NVIC_ISER0	|=NVIC_EXTI3_BPOS;
	
	
	
}
























//working!! fine 


void main(void)
{
	
	
	app_init();
	while(1){
		
		
		*GPIOD_ODR_LOW= count;
		
		
		
		
	}
	
	
	
	
	
	
	
	
}

